package aaa;

public interface ExternalApi {
    String getData();
}

