package ms;

public interface ExternalApi {
    String getData();
}
